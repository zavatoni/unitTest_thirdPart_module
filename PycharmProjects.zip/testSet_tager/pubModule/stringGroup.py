#!/usr/bin/python3
from string import ascii_letters
from string import ascii_lowercase
from string import ascii_uppercase
from errorWar_modu import errors_run_log
from errorWar_modu import result_debug_type
from random import randint, sample


def str_letters(num_lent):
    try:
        letters = ""
        lst_value = [itr for itr in ascii_letters]
        for iter in sample(lst_value, num_lent):
            letters += iter
        return letters
    except:
        errors_run_log()
        return result_debug_type()

def str_lowers_char(num_lent):
    try:
        letters = ""
        lst_value = [itr for itr in ascii_lowercase]
        for iter in sample(lst_value, num_lent):
            letters += iter
        return letters
    except:
        errors_run_log()
        return result_debug_type()

def str_upperscase_char(num_lent):
    try:
        letters = ""
        lst_value = [itr for itr in ascii_uppercase]
        for iter in sample(lst_value, num_lent):
            letters += iter
        return letters
    except:
        errors_run_log()
        return result_debug_type()

'''1、生成固定长度的数字、字母和特殊字符混合的字符串（定义一个类，写在方法里）'''


def group_strChars():
    try:
        lst_special = ['.', '-', '~', '_', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '+', '{', '}', '[', ']',
                       ':',
                       ';', '<', '>', '?', '/']
        # 大写字母+小写字母+数字 +特殊字符.-_~
        lst_chars = [chr(i) for i in range(65, 91)] + [chr(i) for i in range(97, 123)] + [str(i) for i in
                                                                                          range(10)] + lst_special
        num = sample(lst_chars, 10)  # 输出10个固定长度的组合字符
        str_chars = ''
        value = str_chars.join(num)
        return value
    except:
        errors_run_log()
        return result_debug_type()


# 3、生成可自定义长度的数字、字母和特殊字符混合的字符串
def group_strGen(num):
    try:
        lst_special = ['.', '-', '~', '_', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '+', '{', '}', '[', ']',
                       ':',
                       ';', '<', '>', '?', '/']
        # 大写字母+小写字母+数字 +特殊字符.-_~
        lst_chars = [chr(i) for i in range(65, 91)] + [chr(i) for i in range(97, 123)] + [str(i) for i in
                                                                                          range(10)] + lst_special
        value = ""
        for i in range(num):
            value = value + lst_chars[randint(0, len(lst_chars) - 1)]
        return value
    except:
        errors_run_log()
        return result_debug_type()


# 2、生成固定长度不以数字开头的数字、字母和特殊字符混合的字符串（直接写）
def numChar_specialChar():
    try:
        list = [chr(i) for i in range(65, 91)] + [chr(i) for i in range(97, 123)] + [str(i) for i in range(10)] + ['.',
                                                                                                                   '-',
                                                                                                                   '~',
                                                                                                                   '_']
        # 大写字母+小写字母+数字 +特殊字符.-_~
        num = sample(list, 10)  # 输出10个固定长度的组合字符
        str_chars = ''
        values = str_chars.join(num)
        if not values[0].isdigit():
            return values
    except:
        errors_run_log()
        return result_debug_type()


import pyautogui, pandas
from json import dumps


def main():
    print(str_letters(num_lent=52))
    print(str_lowers_char(num_lent=26))
    print(str_upperscase_char(num_lent=26))


if __name__ == '__main__':
    main()
