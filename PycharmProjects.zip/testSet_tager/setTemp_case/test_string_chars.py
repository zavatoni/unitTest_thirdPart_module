#!/usr/bin/python3
import unittest
from errorWar_modu import errors_run_log
from errorWar_modu import result_debug_type

from pubModule.stringGroup import str_lowers_char
from pubModule.stringGroup import str_letters
from pubModule.stringGroup import str_upperscase_char
from pubModule.stringGroup import group_strChars
from pubModule.stringGroup import group_strGen


class TestStringMethods(unittest.TestCase):
    def test_str_lowerCase(self):
        try:
            for str_itm in range(1, 27):
                str_groups = str_lowers_char(num_lent=str_itm)
                if len(str_groups) == str_itm:
                    self.assertEqual(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gs:
                        gs.write('test_str_lowerCase:{}\n'.format(str_groups))
                elif len(str_groups) < str_itm:
                    self.assertLess(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gstr:
                        gstr.write('test_str_lowerCase:{}\n'.format(str_groups))
        except:
            errors_run_log()
            return result_debug_type()

    def test_str_lettersCase(self):
        try:
            for str_itm in range(1, 53):
                str_groups = str_letters(num_lent=str_itm)
                if len(str_groups) == str_itm:
                    self.assertEqual(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gs:
                        gs.write('test_str_lettersCase:{}\n'.format(str_groups))
                elif len(str_groups) < str_itm:
                    self.assertLess(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gstr:
                        gstr.write('test_str_lettersCase:{}\n'.format(str_groups))
        except:
            errors_run_log()
            return result_debug_type()

    def test_str_uppersCase(self):
        try:
            for str_itm in range(1, 27):
                str_groups = str_upperscase_char(num_lent=str_itm)
                if len(str_groups) == str_itm:
                    self.assertEqual(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gs:
                        gs.write('test_str_uppersCase:{}\n'.format(str_groups))
                elif len(str_groups) < str_itm:
                    self.assertLess(len(str_groups), str_itm)
                    with open('group_stringResult.log', 'a') as gstr:
                        gstr.write('test_str_uppersCase:{}\n'.format(str_groups))
        except:
            errors_run_log()
            return result_debug_type()

    # def test_upper(self):
    #     self.assertEqual('foo'.upper(), 'FOO')
    #     foos = 'foo'.upper() == 'FOO'
    #     with open('../cacherStorager/string_testCase.log', 'a') as fo:
    #         fo.write("test_upper:{}\n".format(foos))
    # example case defention

    def test_uppers_charscase(self):
        try:
            for i_str in range(1, 27):
                vStr = str_lowers_char(num_lent=i_str)
                vUppers = vStr.upper()
                self.assertEqual(vStr.upper(), vUppers)
                with open('stringUppers.log', 'a') as su_lg:
                    su_lg.write('test_uppers_charscase:{}\n'.format(vStr))
                    su_lg.write('test_uppers_charscase:{}\n'.format(vUppers))
            else:
                if i_str < 0:
                    self.assertEqual(len(str_lowers_char(num_lent=i_str)), 26)
        except:
            errors_run_log()
            return result_debug_type()

    def test_upperFalses(self):
        try:
            upper_Bool=group_strChars().upper()=='ASDWQ!@#KJ'
            self.assertFalse(upper_Bool)
            self.assertNotEqual(group_strChars().upper(),'SDFJE(*@')
        except:
            errors_run_log()
            return result_debug_type()

    def test_isupper(self):
        self.assertTrue('FOO'.isupper())
        self.assertFalse('Foo'.isupper())
        print(str_letters(length=28))
        with open('../cacherStorager/string_testCase.log', 'a') as fo:
            fo.write("test_isupper:FOO----{}\n".format('FOO'.isupper()))
            fo.write("test_isupper:Foo----{}\n".format('Foo'.isupper()))

    def test_split(self):
        s = 'hello world'
        self.assertEqual(s.split(), ['hello', 'world'])
        # 存储断言的预期值
        if len(s.split()) == 2:
            with open('../cacherStorager/string_testCase.log', 'a') as sp:
                sp.write('test_split==true')
        with self.assertRaises(TypeError):
            s.split(2)


if __name__ == '__main__':
    try:
        unittest.main()
    except:
        errors_run_log()
        print(result_debug_type())
