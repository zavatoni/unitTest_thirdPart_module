#!/usr/bin/python3
import unittest
from errorWar_modu import errors_run_log
from errorWar_modu import result_debug_type

from setCase_module.test_instance import os_path_splitext_abs, os_path_splitext_tuple
from setCase_module.test_instance import os_path_dirName_commany
from setCase_module.test_instance import os_path_split_driver_commany

class TestOS_pathMethods(unittest.TestCase):
    def test_path_splitexts(self):
        try:
            if len(os_path_splitext_abs()) == 2:
                self.assertEqual(len(os_path_splitext_abs()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_abs()))
            if len(os_path_splitext_tuple()) == 2:
                self.assertEqual(len(os_path_splitext_tuple()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_tuple()))
        except:
            errors_run_log()
            return result_debug_type()

    def test_path_splitext_case(self):
        try:
            if len(os_path_splitext_abs()) > 2:
                self.assertGreater(len(os_path_splitext_abs()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_abs()))
            if len(os_path_splitext_abs()) < 2:
                self.assertLess(len(os_path_splitext_abs()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_abs()))

            if len(os_path_splitext_tuple()) < 2:
                self.assertLess(len(os_path_splitext_tuple()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_tuple()))
            if len(os_path_splitext_tuple()) > 2:
                self.assertGreater(len(os_path_splitext_tuple()), 2)
                with open('../cacherStorager/test_os_path.log', 'a') as osItr:
                    osItr.write('os_path_splitext_abs:{}\n'.format(os_path_splitext_tuple()))
        except:
            errors_run_log()
            return result_debug_type()

    def test_os_path_dirName_basicStyle(self):
        try:
            lst_basic = os_path_dirName_commany(lst_dir=[
                "/home/wangzhe/book/1.txt",
                "1.txt",
                "c:\\nianshi\\book\\1.txt",
                "c:/nianshi/book/1.txt"
            ])
            for itr in lst_basic:
                if len(itr) > 0:
                    self.assertGreater(len(itr), 0)
                    with open('../cacherStorager/test_os_path.log', 'a') as wri_itr:
                        wri_itr.write('os_path_dirName:{}:{}\n'.format(len(itr), itr))
                elif len(itr) == 0:
                    self.assertEqual(len(itr), 0)
                    with open('../cacherStorager/test_os_path.log', 'a') as wri_itr:
                        wri_itr.write('os_path_dirName:{}:{}\n'.format(len(itr), itr))
        except:
            errors_run_log()
            return result_debug_type()

    def test_os_path_dirName_baseStyle(self):
        try:
            lst_basic = os_path_dirName_commany(lst_dir=[
                "/home/wangzhe/book/1.txt",
                "1.txt",
                "c:\\nianshi\\book\\1.txt",
                "c:/nianshi/book/1.txt"
            ])
            for itr in lst_basic:
                if len(itr) < 0:
                    self.assertLess(len(itr), 0)
                    with open('../cacherStorager/test_os_path.log', 'a') as wri_itr:
                        wri_itr.write('os_path_dirName:{}:{}\n'.format(len(itr), itr))
                else:
                    self.assertRaises(ValueError)
                    # with open('test_os_path.log', 'a') as wri_itr:
                    #     wri_itr.write('os_path_dirName:{}:{}\n'.format(len(itr), itr))

        except:
            errors_run_log()
            return result_debug_type()
    def test_osPath_split_drivers(self):
        try:
            # caseResult:True
            lst_device = os_path_split_driver_commany(lst_device=[
                "/home/wangzhe/book/1.txt",
                "1.txt",
                "c:\\nianshi\\book\\1.txt",
                "c:/nianshi/book/1.txt"
            ])
            for itr in lst_device:
                if len(itr) == 2:
                    self.assertEqual(len(itr), 2)
                    with open('../cacherStorager/test_os_path.log', 'a') as iter:
                        iter.write('os_path_split_driver:{}\n'.format(itr))
        except:
            errors_run_log()
            return result_debug_type()

    def test_osPath_split_driver_case(self):
        try:
            # caseResult:Fail
            lst_device = os_path_split_driver_commany(lst_device=[
                "/home/wangzhe/book/1.txt",
                "1.txt",
                "c:\\nianshi\\book\\1.txt",
                "c:/nianshi/book/1.txt"
            ])
            for itr in lst_device:
                if len(itr) > 2:
                    self.assertGreater(len(itr), 2)
                    with open('../cacherStorager/test_os_path.log', 'a') as iter:
                        iter.write('os_path_split_driver:{}\n'.format(itr))
                elif len(itr) < 2:
                    self.assertLess(len(itr), 2)
                    with open('../cacherStorager/test_os_path.log', 'a') as iter:
                        iter.write('os_path_split_driver:{}\n'.format(itr))
        except:
            errors_run_log()
            return result_debug_type()
if __name__ == '__main__':
    unittest.main()