#!/usr/bin/python3
import pandas, numpy
from errorWar_modu import errors_run_log
from errorWar_modu import result_debug_type
from xlwt import Workbook


def workBook_writeObj():
    v_book = Workbook(encoding='utf-8')
    v_sheet1 = v_book.add_sheet(u'Sheet1', cell_overwrite_ok=True)
    # v_sheet1.write(0,0,'123425')
    for itr in range(10):
        v_sheet1.write(0, itr, 'erwerw')
        v_sheet1.write(1, itr, 'erwerw')
        v_sheet1.write(2, itr, 'erwerw')
        v_sheet1.write(itr, 0, 'erwerw')
        v_sheet1.write(itr, 1, 'erwerw')
        v_sheet1.write(itr, 2, 'erwerw')

    v_book.save('path_temp.xlsx')


def frameTo_excel():
    try:
        df1 = pandas.DataFrame(
            {
                'v1': numpy.random.rand(100),
                'v2': numpy.random.rand(100),
                'v3': numpy.random.rand(100)
            }
        )
        with pandas.ExcelWriter('path_to_fileTemp.xlsx') as tmp:
            df1.to_excel(tmp)
        df_tmp = pandas.DataFrame(
            [
                numpy.random.rand(10),
                numpy.random.rand(10),
                numpy.random.rand(10)
            ]
        )
        with pandas.ExcelWriter('path_to_fileTemp.xlsx') as wri_tmp:
            df_tmp.to_excel(wri_tmp)
        # v_df=pand
        # print(df_tmp)
    except:
        errors_run_log()
        return result_debug_type()


def main():
    workBook_writeObj()
    # frameTo_excel()


if __name__ == '__main__':
    main()
