#!/usr/bin/python3
from os import path
from errorWar_modu import errors_run_log
from errorWar_modu import result_debug_type
from pubModule.stringGroup import str_letters,str_uppercase,str_lowercase
from pubModule.stringGroup import group_strGen,group_strChars,numChar_specialChar


def os_path_split_driver_commany(lst_device):
    try:
        lst_stor = []
        # 作用：一般用在windows下，返回驱动器名和路径组成的元组。
        for itr in lst_device:
            lst_stor.append(path.splitdrive(itr))
        return lst_stor
    except:
        errors_run_log()
        return result_debug_type()


def os_path_split_commany(lst_split):
    try:
        lst_stor = []
        # 作用是把路径分割成dirname和basename，返回一个元组。
        for itr in lst_split:
            lst_stor.append(path.split(itr))
        return lst_stor
    except:
        errors_run_log()
        return result_debug_type()


def os_path_splitext_tuple():
    try:
        lst_text = path.splitext("wangzhe.txt")
        return lst_text
    # 作用是：分割路径，返回路径文件名和文件扩展名组成的元组。
    except:
        errors_run_log()
        return result_debug_type()


def os_path_splitext_abs():
    try:
        lst_text = path.splitext("/home/wangzhe/test.txt")
        return lst_text
    # 作用是：分割路径，返回路径文件名和文件扩展名组成的元组。
    except:
        errors_run_log()
        return result_debug_type()


def os_path_dirName_commany(lst_dir):
    try:
        lst_result = []
        # 作用：返回文件所在的路径
        for itr in lst_dir:
            lst_result.append(path.dirname(itr))
        return lst_result
    except:
        errors_run_log()
        return result_debug_type()


def main():
    print(
        os_path_split_driver_commany(lst_device=[
            "/home/wangzhe/book/1.txt",
            "1.txt",
            "c:\\nianshi\\book\\1.txt",
            "c:/nianshi/book/1.txt"
        ])
    )


if __name__ == '__main__':
    main()
